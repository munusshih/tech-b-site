# An oracle that remembers you

Technology B, Week 13. Ten model workshops and four visual outcomes.

## Start

1. Install Node.js 24 LTS from https://nodejs.org/en/download .
2. Open a terminal in this unzipped folder.
3. Start Llama App or Ollama, load a local chat model, and start its API server.
4. Run npm start. Core examples need no npm install.
5. Open http://127.0.0.1:3213 and connect.

The MCP client and small demo server run in your browser using the bundled official SDK and a linked in-memory transport. No npm install is required to run the download. Discovery and calls exchange real MCP messages; inspect them in the request log. This classroom demo does not connect to external MCP services.

## Files

- index.html: interface and teaching notes
- examples/: one short JavaScript lesson per concept
- shared.js: model requests, keyword retrieval, embeddings, and bounded tool loops
- app.js: form controls, status, traces, and browser memory
- server.mjs: loopback-only model proxy and information retrieval
- mcp-client.js: browser MCP connection and initialization
- mcp-server.js: tiny read-only MCP archive
- mcp-sdk.js: bundled official MCP SDK

Edit a lesson file and refresh the browser. No build command is needed. Restart npm start after changing server.mjs.

## Models and connections

Llama App: http://127.0.0.1:9931
Ollama: http://127.0.0.1:11434

Keep npm start running to use this folder as the local model bridge for https://tech-b.munusshih.com. The published workshop will use it if direct browser access is blocked. It allows only that exact website origin, only model-list, chat, and embedding routes, and only loopback model servers. No Llama agent-control routes are exposed. You can also use the downloaded interface at http://127.0.0.1:3213.

Use the model menu to choose a loaded chat model. JSON Schema and tool support depend on model and server. Errors are shown rather than replaced by fake results. Inference never uses a commercial service. Downloads and model installation need internet initially.

The optional semantic retrieval modes in RAG need a separate embedding model. For Llama run:

    llama serve -hf unsloth/embeddinggemma-300m-GGUF --embedding --port 9932

For Ollama run ollama pull embeddinggemma, then use embedding server URL http://127.0.0.1:11434 and model name embeddinggemma in the form. The chat and embedding models are different. Download GGUF files at https://huggingface.co/unsloth/embeddinggemma-300m-GGUF/tree/main or see https://ollama.com/library/embeddinggemma .

Web search needs internet. The layout agent runs entirely locally. Search snippets are incomplete; open source links to verify. Tool loops allow at most three calls per turn and three tool rounds, followed by a final call without tools. The agent trace logs application actions, not hidden reasoning.

SearXNG is optional. Run a local instance at http://127.0.0.1:8080 and enable JSON in settings.yml (search.formats includes json). To use another local address, set SEARXNG_BASE before npm start. Rate limits and blocked search engines can still affect results.

Memory is a model-written summary stored in this browser's localStorage on the local origin. It survives a reload. Edit or forget it using the interface; clearing site data also removes it. Other lessons do not read that summary. It is not stored in a JSON file.

## Creative coding outcomes A–D

The visual-outcomes folder contains four different provotypes. A turns a frustrated note into a fictional office circular, using GSAP and typography. B writes a reflective oracle and paints a symbolic card using p5.js and p5.brush; an editable memory is stored in this browser. C retrieves public-domain Met artworks, then gives a curator, researcher, and editor separate jobs in constructing an exhibition. D is an alarm-clock negotiation: actual tool calls grant snooze time, ask questions, or request short Tone.js protests. No sound starts until you enable it. This clock runs in the page; it is not a system alarm and does not resume after a reload.

Libraries are bundled locally, with readable originals in visual-outcomes/sources/. Core examples and A, B, and D use only the local model connection. The Met needs internet but no API key. Existing public-domain images stay linked to their original records. Sessions can be exported or cleared in each project. No model-written code is executed.

To rebuild a modified output, install p5@2.4.0 p5.brush@3.0.0 gsap rough-notation tone and esbuild, then bundle sources/notice.js, sources/oracle.js, sources/archive.js, and sources/clock.js with --bundle --splitting --format=esm --platform=browser --outdir=visual-outcomes/renderers. Run the command from the unzipped root folder and prefix each entry point with visual-outcomes/.

The model interactions live in visual-outcomes/scores.js. The code has bounded responses, one correction attempt for structured replies, and checked tool arguments. Browser storage belongs to the local origin: opening the downloads on another port starts with a separate memory.

## Teaching questions

### Prompting

The model receives two pieces of text: instructions about how to respond, and your message. Compare the same message with and without the instructions.

Try: Compare the same project description with and without the visitor-focused instructions. Then change the audience to a six-year-old.

Change: Try removing the role entirely. Does the model still follow the requested length?

Discuss: Does a confident voice make the answer more trustworthy?

### Temperature

Write the same short installation message at three temperatures and compare variation and constraint-following.

Try: Compare the three messages. Do they all invite the visitor to wave, and do they stay within 12 words?

Change: Repeat without editing the prompt, then adjust one temperature. Compare clarity as well as novelty.

Discuss: When might repetition be more useful than surprise?

### Structured outputs

Paste an informal event announcement. Compare a text extraction with validated JSON, then see the same JSON fields populate an event card.

Try: Change the announcement’s time or location and watch the event card update. Remove the location entirely: it should show “Not provided,” not an invented venue.

Change: Remove the date or venue, run again, and inspect how the empty field appears in the event card.

Discuss: Which details should the interface ask someone to confirm before publishing?

### Tool calling

The model extracts quantities from a materials request and calls a JavaScript function with fixed prices. The function produces the receipt.

Try: Run the $20 budget check, then remove two batteries and compare the receipt.

Change: Change quantities or budget. Check which values come from the model and which come from your function.

Discuss: Who decides which actions the model is allowed to take?

### RAG

Find passages in a fictional studio handbook using keywords or embeddings, then use those passages to answer a booking question.

Try: Run keyword retrieval, then compare both methods with the same question. The semantic options need an embedding model.

Change: Change the risograph booking rule. Does the answer follow the updated source?

Discuss: What happens to knowledge that the retriever cannot find?

### Agents

An agent submits floor-plan coordinates to a local geometric checker and revises them from the returned issues. No internet is needed.

Try: Allow one round to see the broken starting plan, then allow three to give it a chance to repair it.

Change: Change the starting coordinates. Watch whether each tested revision actually fixes the checker’s issues.

Discuss: What should happen when a model never decides it is finished?

### Web search

Searching and generating are separate steps. This example searches Wikipedia first, shows the source snippets, then sends them to your local model.

Try: Look up Isotype as a reference for designing a set of public-information icons. Check which claims in the answer actually appear in the retrieved snippets.

Change: Ask a question not covered by the returned snippets. Does the answer admit the gap?

Discuss: How does the search provider shape the answer?

### Memory

A fresh model request has no memory of this page. The application saves a short summary and sends it with your next message. You can read, correct, or erase that summary.

Try: Send this installation brief. Then use “Ask a follow-up” to request materials and a first test. Does the answer retain the budget and interaction constraints? Forget the summary and compare.

Change: Correct the summary manually. Ask a question again and compare.

Discuss: What should an application remember, forget, or let someone correct?

### Multi-agent systems

Four roles collaborate: a designer, two independent specialist reviewers, and a producer who synthesizes their feedback.

Try: Compare the first proposal with the final plan. Trace one concrete improvement back to each reviewer.

Change: Edit the fabrication reviewer to prioritize repair and reuse. Check whether the final materials change.

Discuss: Does adding more voices make a process more accountable?

### MCP

The browser connects an MCP client and a small archive server using the official SDK. It discovers the tool schema, offers it to the model, and routes tool calls back through MCP.

Try: Discover the archive tool and inspect its schema, then ask a question. Both client and demo server run in this browser; no terminal is needed.

Change: Change the archive in mcp-server.js in the download, refresh, and ask again.

Discuss: What changes when tools come from a separate program?

## Official references

- https://llama.app/docs/api
- https://llama.app/docs/serve
- https://docs.ollama.com/api/openai-compatibility
- https://www.mediawiki.org/wiki/API:Search
- https://docs.searxng.org/dev/search_api.html
- https://github.com/modelcontextprotocol/typescript-sdk
- https://modelcontextprotocol.io/docs/tools/inspector
